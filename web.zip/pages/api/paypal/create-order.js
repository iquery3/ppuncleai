import axios from "axios";
import { getPayPalToken } from "../../../utils/paypal";

export default async function handler(req, res) {
    if (req.method !== "POST") {
        return res.status(405).json({ error: "Method Not Allowed" });
    }

    const { order_id, total, currency, return_url, cancel_url } = req.body;

    try {
        const accessToken = await getPayPalToken();

        const orderData = {
            intent: "CAPTURE",
            purchase_units: [{
                reference_id: order_id,
                amount: { currency_code: currency, value: total },
            }],
            application_context: {
                return_url,
                cancel_url,
            },
        };

        const response = await axios.post("https://api-m.paypal.com/v2/checkout/orders", orderData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });

        res.status(200).json(response.data);
    } catch (error) {
        console.error("PayPal Create Order Error:", error.response?.data || error.message);
        res.status(500).json({ error: "Failed to create PayPal order" });
    }
}