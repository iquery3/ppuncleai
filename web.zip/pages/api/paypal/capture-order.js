import axios from "axios";
import { getPayPalToken } from "../../../utils/paypal";

export default async function handler(req, res) {
    if (req.method !== "POST") {
        return res.status(405).json({ error: "Method Not Allowed" });
    }

    const { paypal_order_id } = req.body;

    try {
        const accessToken = await getPayPalToken();

        const captureUrl = `https://api-m.paypal.com/v2/checkout/orders/${paypal_order_id}/capture`;
        const response = await axios.post(captureUrl, {}, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });

        res.status(200).json(response.data);
    } catch (error) {
        console.error("PayPal Capture Order Error:", error.response?.data || error.message);
        res.status(500).json({ error: "Failed to capture PayPal order" });
    }
}